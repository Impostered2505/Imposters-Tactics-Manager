!!!READ ME!!!
MY FIRST PROJECT
ONLY RUSSIAN LANGUAGE
-----------------------------------------------------------------------------

Russian alpha concept version of Imposter's Tactics Manager.

ITM - program for creating and editing football tactics. It supports the creation, addition, import, and export of tactics and players.

Version: A.0.1.ITM.C (Alpha Concept)

Other languages will be added in A.0.2.ITM.

History of versions:

A.0.0 - 1st version. Won't be released. Although maybe much later I’ll add it to some version.

A.0.1.ITM.C - Concept of the future version A.0.1.ITM (new interface, icons, themes, etc.)



PS: Liverpool is the best FC itw YNWA